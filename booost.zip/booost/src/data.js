export const SocialLinks = [
    { 
    id: 1,
    iconSrc: <img src={require('./images/instagram.png')} alt="insta"/>,
    link: "https://github.com/dotsbeauty",
  },
    { 
    id: 2,
    iconSrc: <img src={require('./images/facebook.png')} alt="insta"/>,
    link: "https://github.com/dotsbeauty",
  },
    { 
    id: 3,
    iconSrc: <img src={require('./images/Youtube.png')} alt="insta"/>,
    link: "https://github.com/dotsbeauty",
  },
    { 
    id: 4,
    iconSrc: <img src={require('./images/Linkdin.png')} alt="insta"/>,
    link: "https://github.com/dotsbeauty",
  },
]
  export const SocialMedia = [
    { 
      id: 1,
      iconSrc: <img src={require('./images/yt.png')} alt="YouTube"/>,
      classStyle: "yt",
      link: "https://github.com/dotsbeauty",
    },
      { 
      id: 2,
      iconSrc: <img src={require('./images/fb.png')} alt="FaceBook"/>,
      classStyle: "fb",
      link: "https://github.com/dotsbeauty",
    },
      { 
      id: 3,
      iconSrc: <img src={require('./images/ig.png')} alt="InstaGram"/>,
      classStyle: "ig",
      link: "https://github.com/dotsbeauty",
    },
      { 
      id: 4,
      iconSrc: <img src={require('./images/tw.png')} alt="Twitter"/>,
      classStyle: "tw",
      link: "https://github.com/dotsbeauty",
    },
      { 
      id: 5,
      iconSrc: <img src={require('./images/ld.png')} alt="LinkedIn"/>,
      classStyle: "ld",
      link: "https://github.com/dotsbeauty",
    },
    
  ]