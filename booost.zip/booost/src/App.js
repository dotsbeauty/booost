import './App.css';
import hero from './images/hero75.png';
import { SocialMedia, SocialLinks } from "./data";
import { motion} from "framer-motion";
function App() {
  return (
  <div className="app__content">
      
    <div className='app__container'>
      <img src={require('./images/logo.png')} className="app__logo" alt='logo'/>

      <div className='app__title'>
        <div className='soon'> 
           <p className='dash1'></p>
           <p className='app__soon'>Coming Soon</p>
           <p className='dash2'></p>
        </div>
        <p className='app__main'>Get Notified When We Launch</p>
        <a href='www.google.com'><button>Join Us</button></a>
        <p className='worry'>Don't worry we will not spam you</p>
        <img className='app__hero' src ={hero} alt='hero'/>
      </div>

        <div className='circle'>
          {SocialMedia && SocialMedia.map((n) =>(
                         
            <motion.div 
            key={n.id} 
            className={n.classStyle}
            initial={{}}
            animate={{
              x: [-20, 20],
              y: [0,-15],
              transition: {
                x:{
                  yoyo: Infinity,
                  duration: 0.5
                },
                y: {
                  yoyo: Infinity,
                  duration: 0.25
                }
              }}}
            >
              {n.iconSrc}
            </motion.div>


          ))}
        </div> 


        <div className='app__tray'>
          {SocialLinks && SocialLinks.map((n) => (
                  <a
                    whileTap={{ scale: 0.8 }}
                    href={n.link}
                    key={n.id}
                    className='app__social'
                  >
                    {n.iconSrc}
                  </a>
                ))}
        </div>
    </div>

  </div>
  );
}

export default App;
